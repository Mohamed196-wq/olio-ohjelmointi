# C++ Kotitehtävä 1 – H1

Harjoitus 1: `cout`, `cin` ja funktiot.

Ohjelma kysyy kaksi kokonaislukua ja laskee niiden summan sekä osamäärän. Osamäärä tulostetaan kahdella desimaalilla.

Ohjelmassa ovat opettajan tehtävänannossa pyydetyt funktiot:

- `calcSum(int a, int b)` tulostaa summan.
- `calcDiv(int a, int b)` tulostaa osamäärän, ja jos jakaja on nolla, virheilmoituksen.
- `retSum(int a, int b)` palauttaa summan.
- `retDiv(int a, int b)` palauttaa `float`-tyyppisen osamäärän tai heittää `std::runtime_error`-poikkeuksen, jos jakaja on nolla.

`main()` lukee luvut ja kutsuu kaikkia funktioita. `retDiv()`-funktion mahdollinen virhe käsitellään `try`–`catch`-rakenteella.

## Kääntäminen ja suorittaminen

Projektin voi avata Qt Creatorissa valitsemalla `CMakeLists.txt`-tiedoston. Vaihtoehtoisesti esimerkiksi g++-kääntäjällä:

```bash
g++ -std=c++17 main.cpp -o h1
./h1
```

Windowsissa g++-kääntäjän luoman `h1.exe`-tiedoston voi käynnistää komennolla `h1.exe`.

## Esimerkkisuoritus

Syöte: `10` ja `4`.

```text
Anna ensimmainen luku: 10
Anna toinen luku: 4
Summa: 14
Osamaara: 2.50
Palautettu summa: 14
10 / 4 = 2.50
```
