#include <iostream>
#include <iomanip>
#include <stdexcept>

using namespace std;

// Tulostaa kahden kokonaisluvun summan.
void calcSum(int a, int b) {
    cout << "Summa: " << a + b << endl;
}

// Tulostaa osamaaran tai virheilmoituksen, jos jakaja on nolla.
void calcDiv(int a, int b) {
    if (b == 0) {
        cout << "Virhe: jakaja ei saa olla nolla!" << endl;
    } else {
        cout << "Osamaara: " << static_cast<float>(a) / b << endl;
    }
}

// Palauttaa summan, ei tulosta.
int retSum(int a, int b) {
    return a + b;
}

// Palauttaa osamaaran tai heittaa poikkeuksen.
float retDiv(int a, int b) {
    if (b == 0) {
        throw runtime_error("jakaja ei saa olla nolla!");
    }
    return static_cast<float>(a) / b;
}

int main() {
    int a, b;

    cout << "Anna ensimmainen luku: ";
    if (!(cin >> a)) {
        cerr << "Virhe: anna kokonaisluku." << endl;
        return 1;
    }

    cout << "Anna toinen luku: ";
    if (!(cin >> b)) {
        cerr << "Virhe: anna kokonaisluku." << endl;
        return 1;
    }

    cout << fixed << setprecision(2);

    calcSum(a, b);
    calcDiv(a, b);

    cout << "Palautettu summa: " << retSum(a, b) << endl;

    try {
        float result = retDiv(a, b);
        cout << a << " / " << b << " = " << result << endl;
    } catch (const runtime_error& e) {
        cout << "Error: " << e.what() << endl;
    }

    return 0;
}
