C++ KOTITEHTAVA 1 (H1)

Projektin tiedostot:
- main.cpp       C++-ohjelma
- CMakeLists.txt Qt Creatorilla tai CMake-ohjelmalla avattava projekti

Ohjelman tehtava:
1. Pyydetaan kayttajalta kaksi kokonaislukua a ja b.
2. calcSum(a,b) tulostaa summan.
3. calcDiv(a,b) tulostaa osamaaran kahdella desimaalilla; nollajakajasta virheviesti.
4. retSum(a,b) palauttaa summan.
5. retDiv(a,b) palauttaa float-osamaaran ja heittaa runtime_error-poikkeuksen, jos jakaja on nolla.
6. main() tulostaa palautuneet arvot ja kasittelee poikkeuksen try-catch-rakenteella.

KAYTTO WINDOWSISSA
- Pura h1.zip.
- Jos Qt Creator on asennettuna, avaa Qt Creatorissa h1/CMakeLists.txt.
- Valitse toimiva C++-kit/kaannintyokalu, rakenna ja suorita.
- Vaihtoehtoisesti g++-kaantajalla:
    g++ -std=c++17 main.cpp -o h1.exe
    h1.exe

PALAUTUS
- Tarkista, etta ohjelma kaantyy ja tulostaa oikeat arvot.
- Lataa omat projektitiedostosi GitHub-arkistoosi ohjeen mukaan.
- Palauta Moodleen linkki oman arkistosi h1-projektiin, jos kurssin ohje niin vaatii.
